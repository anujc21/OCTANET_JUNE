import React from "react";

function Footer(){
	return (
		<div className="footer">
			<h3 className="footerText">
				💎 Created by Anuj Chowdhury 💎
			</h3>
		</div>
	);
}

export default Footer;