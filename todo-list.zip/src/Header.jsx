import React from "react";

function Header(){
	return (
		<div className="header">
			<span className="material-symbols-outlined headerIcon">
				receipt_long
			</span>

			<h1 className="headerTitle">
				To-Do List
			</h1>
		</div>
	);
}

export default Header;