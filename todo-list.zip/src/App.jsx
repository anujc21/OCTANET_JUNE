import React from "react";
import Header from "./Header.jsx";
import Container from "./Container.jsx";
import "./App.css";

function App(){
    return (
        <div className="app">
            <Header/>
            
            <div className="content">
                <Container/>
            </div>
        </div>
    );
}

export default App;