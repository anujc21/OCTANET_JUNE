import React, {useState, useRef} from "react";

function Container(){
	const inputRef = useRef();

	const timeRef = useRef();

	const [list, setList] = useState([]);

	const removeItem = (index) => {
		setList((oldList) => {
			const newList = [...oldList];

			newList.splice(index, 1);

			return newList;
		});
	};

	const switchUp = (index) => {
		setList((oldList) => {
			const newList = [...oldList];

			const newItem = newList[index];

			if (index !== 0){
				newList[index] = newList[index - 1];
				newList[index - 1] = newItem;
			}

			return newList;
		});
	};

	const switchDown = (index) => {
		setList((oldList) => {
			const newList = [...oldList];

			const newItem = newList[index];

			if (index !== (newList.length - 1)){
				newList[index] = newList[index + 1];
				newList[index + 1] = newItem;
			}
			
			return newList;
		});
	};

	const itemDone = (index) => {
		setList((oldList) => {
			const newList = [...oldList];

			if (newList[index].done){
				newList[index].done = false;
			}
			else{
				newList[index].done = true;
			}

			return newList;
		});
	};

	const data = (index) => {
		const item = list[index];

		if (item.done){
			return (
				<s>
					{item.data}
				</s>
			);
		}
		else{
			return item.data;
		}
	};

	const listItems = list.map((item, index) => {
		const dataValue = data(index);

		return (
			<div className="listItem" key={index}>
				<div className="itemIndex">
					{index + 1}.
				</div>

				<div className="itemValue" onClick={() => {itemDone(index)}}>
					{dataValue}
				</div>

				<div className="itemDeleteButton" onClick={() => {removeItem(index)}}>
					<span className="material-symbols-outlined">
						delete
					</span>
				</div>

				<div className="itemSwitchButtons">
					<span className="material-symbols-outlined itemSwitchButton" onClick={() => {switchUp(index)}}>
						keyboard_arrow_up
					</span>

					<span className="material-symbols-outlined itemSwitchButton" onClick={() => {switchDown(index)}}>
						keyboard_arrow_down
					</span>
				</div>
			</div>
		);
	});

	const addItem = () => {
		const value = inputRef.current.value;

		const time = timeRef.current.value;

		if (value){
			setList((oldList) => {
				const newList = [...oldList, {
					done: false,
					data: time ? `${value} - [${time}]` : value
				}];

				return newList;
			});

			inputRef.current.value = "";
		}
	};

	return (
		<div className="container">
			<div className="addInputContainer">
				<div className="addInputBox">
					<input className="addInput" ref={inputRef}/>

					<input className="timeInput" type="time" ref={timeRef}/>
				</div>

				<div className="addButton" onClick={addItem}>
					<span className="material-symbols-outlined addButtonIcon">
						add
					</span>
				</div>
			</div>

			<div className="listContainer">
				<div className="listBox">
					{listItems}
				</div>
			</div>
		</div>
	);
}

export default Container;